export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        neon: '#00FFFF',
        dark: '#0D1117',
        glass: 'rgba(255, 255, 255, 0.05)',
      },
      fontFamily: {
        orbitron: ['Orbitron', 'sans-serif'],
      },
      backdropBlur: {
        xs: '2px',
      },
      boxShadow: {
        neon: '0 0 20px rgba(0, 255, 255, 0.5)',
      }
    },
  },
  plugins: [],
}
