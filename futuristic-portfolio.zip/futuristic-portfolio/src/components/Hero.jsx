import { motion } from 'framer-motion';

const Hero = () => {
  return (
    <section className="h-screen flex items-center justify-center bg-dark text-neon font-orbitron">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="text-center backdrop-blur-xs bg-glass p-6 rounded-2xl border border-neon/20 shadow-neon"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Lakshay Dhingra</h1>
        <p className="text-lg md:text-xl text-neon/80">
          Financial Analyst · Investment Banking · Investment Analyst · Investment Advisor
        </p>
      </motion.div>
    </section>
  );
};

export default Hero;
