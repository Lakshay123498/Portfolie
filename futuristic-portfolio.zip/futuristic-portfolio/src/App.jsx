import Hero from './components/Hero';

function App() {
  return (
    <div className="bg-dark min-h-screen">
      <Hero />
    </div>
  );
}

export default App;
